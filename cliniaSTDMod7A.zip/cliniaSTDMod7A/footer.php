<div id="footerTop">
    <div id="about" class="col-md-5">
        <h2>Sobre Nós</h2>
        <?=$sobre?>
    </div>
    <div id="Twitter" class="col-md-3">
        <h2>Twitter</h2>
        <p>
        <a class="twitter-timeline" href="https://twitter.com/hashtag/ahiruproductions" data-widget-id="608578371639980032">ahiruproductions Tweets</a>
        <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
        </p>
    </div>
    <div id="contact" class="col-md-2">
        <h2>As nossas clinicas</h2>
        <ul style="list-style: none; margin-left: -35px">
            <li>STD Lisboa</li>
            <li>STD Porto</li>
            <li>STD Coimbra</li>
            <li>STD Faro</li>
        </ul>
    </div>
    <div id="clearBoth">
        oaef
    </div>
</div>
<div id="footerBottom">
    Copyrights &copy; 2015, <a href="http://www.ahiruproductions.com">Ahiru Productions</a>
    <div id="social" class="pull-right">
        <ul>
            <a href="https://www.facebook.com/" target="_blank"><li class="facebook" data-toggle="tooltip" data-placement="top" title="Facebook"></li></a>
            <a href="https://twitter.com/" target="_blank"><li class="twitter" data-toggle="tooltip" data-placement="top" title="Twitter"></li></a>
            <a href="https://www.youtube.com/" target="_blank"><li class="youtube" data-toggle="tooltip" data-placement="top" title="YouTube"></li></a>
            <a href="mailto:geral@stdpsiquiatria.pt"><li class="mail" data-toggle="tooltip" data-placement="top" title="Mail"></li></a>
            <script>
                $(function () {
                  $('[data-toggle="tooltip"]').tooltip()
                })
            </script>
        </ul>
    </div>
</div>
